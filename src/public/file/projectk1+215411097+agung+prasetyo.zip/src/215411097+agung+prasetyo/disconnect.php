<?php

require_once "connect.php";

// Menutup koneksi database
$conn->close();
